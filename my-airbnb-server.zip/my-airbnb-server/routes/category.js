const express=require('express')
// to login in mysql database 
const db = require('../db')
// to send response ex create error .
const utils = require('../utils')

const multer=require('multer')

const upload =multer({ dest:'images'})//might be check

const router =express.Router()


router.post('/',upload.single('icon'),(request,response)=>{
    const{title,details}=request.body
    console.log(title)
    const fileName=request.file.filename

    const statement=`insert into category (title,details,image) values (?,?,?)`
    db.pool.execute(statement,[title,details,fileName],(error,categories)=>{
    response.send(utils.createResult(error,categories))
  })  
})

router.get('/',(request,response)=>{
    // const{title,details}=request.body

    // const fileName=request.file.filename

    const statement=`select id,title,details,image from category`
    db.pool.execute(statement,(error,categories)=>{
    response.send(utils.createResult(error,categories))
  })  
})




module.exports =router