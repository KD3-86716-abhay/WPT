// const express=require('express')
// const db=require('../db')//after query fire login to db which db to choose 
// const utils=require('../utils')//after successful fire query  it response
// const crypto=require('crypto-js')//used to encrypt and decrypt require crypto
// const jwt=require('jsonwebtoken')
// const config=require('../config')

// const router = express.Router()

// //the router method get or post is provided write here /register endpoint 
// router.post('/register',(request,response)=>{
//     console.log("inside register");
//     const {firstName,lastName,email,password,phone}=request.body
//     const statement=`insert into user (firstName,lastName,email,password,phoneNumber)values(?,?,?,?,?)`
//     const encryptedPassword=String(crypto.SHA256(password))
//     db.pool.execute(
//         statement,
//         [firstName,lastName,email,encryptedPassword,phone],
//         (error,result)=>{
//             response.send(utils.createResult(error,result))
//         }
//         )
// })

// //api post/get  

// module.exports =router


const express=require('express')
// to login in mysql database 
const db = require('../db')
// to send response ex create error .
const utils = require('../utils')
//to encrypt and decrypt password 
const crypto = require('crypto-js')
const jwt=require('jsonwebtoken')
const config=require('../config')

// const cors=require('cors')
// const utils=require('../utils')

const router = express.Router()

//delete profile of user from table with the help of delete command
// router.put('/profile/',(request,response)=>{
//     const {firstName,lastName,phone}=request.body
//     const statement=`update user set firstName =?,lastName=?,phoneNumber=? where id= ? `
//     db.pool.execute(statement,[firstName,lastName,phone,request.userId],(error,result)=>{
//         response.send(utils.createResult(error,result));
//     })
// })



//for update profile of users in table
router.put('/profile/',(request,response)=>{
    const {firstName,lastName,phone}=request.body
    const statement=`update user set firstName =?,lastName=?,phoneNumber=? where id= ? `
    db.pool.execute(statement,[firstName,lastName,phone,request.userId],(error,result)=>{
        response.send(utils.createResult(error,result));
    })
})


router.get('/profile/',(request,response)=>{
    const statement=`select firstName,lastName,phoneNumber,email from user where id= ? `
    db.pool.execute(statement,[request.userId],(error,result)=>{
        response.send(utils.createResult(error,result));
    })
})

// this routes listens for post requests to the /regester endpoint.
router.post('/register',(request,response)=>{
    console.log("inside register") ; 
    
    const { firstName , lastName , email , password, phone } = request.body
    const statement = `insert into user(firstName, lastName, email, password, phoneNumber) values(?,?,?,?,?)`
    const encryptedPassword = String(crypto.SHA256(password))
    db.pool.execute(
        statement,
        [firstName, lastName , email, encryptedPassword , phone], // this will send this values to the respected questionmarks ? 
        (error, result) =>{
            console.log("** ", error)
            response.send(utils.createResult(error,result))
        }
    )
})
router.post('/login',(request,response)=>{
    console.log("inside login");
    const {email,password }=request.body
    const statement=`select id,firstName,lastName,phoneNumber,isDeleted from user where email=? and password=?;`
    const encryptedPassword=String(crypto.SHA256(password))
    db.pool.query(statement,[email,encryptedPassword],(error,users)=>{
        if(error){
        response.send(utils.createErrorResult(error))
        }else{
            if(users.length==0){
                response.send(utils.createErrorResult('user does not exist'))
            }else{
                console.log("*",users)
                const user=users[0]
                console.log("**",users[0]);
                if(user.isDeleted){
                    response.send(utils.createErrorResult('your account is closed'))
                }else{
                    //create the payload
                    const payload={id: user.id}
                    const token=jwt.sign(payload,config.secret)
                    console.log("***",token)
                    const userData={
                        token,
                        name:`${user['firstName']} ${user['lastName']}`,
                    }
                    response.send(utils.createSuccessResult(userData))
                }
            }
        }
    })
})







module.exports =router