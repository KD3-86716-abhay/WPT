// const express=require('express')
// const cors=require('cors')
// //handle cross origin errror
// const jwt=require('jsonwebtoken')
// //used for authentication and verification purpose
// const config=require('./config')
// //imports a config file from same directory 
// //settings amd constants

// const utils=require('./utils')
// //reusable functions and helpers for your application

// const app = express()
// //this lines create new instances of the express.js application
// //main entry point for your server
// app.use(cors())
// //enables cors middleware for your application
// app.use(express.json())
// // enables json parsing for incoming requests.
// //this middlewarre parses incoming requests with json payloads
// //and makes the data available in the req.body object

// //by usign app.use(express.json()), you are telling express.js to parse the data sent in the request body
// //this is useful for  


// //middleware to verify the token
// app.use((request,express,response,next)=>{
//     //check if token is required for the api
//     if(
//         request.url==='/user/login'||
//         request.url==='/user/register'||
//         request.url.startswith('/image')

//     ){
//         next()
        
//     }else {
//         console.log("login successful");
//     }

// })



// const userRouter = require('./routes/user')
// // const registerRouter = require('./routes/register')

// // const categoryRouter=require('./routes/category')




// app.use('/user',userRouter)


// app.listen(4000,'0.0.0.0',()=>{
//     console.log(`server started on port 4000`)
// })


const express=require('express')
// allows your server to accept 
// requests from different orgins (e.g. different domain ports)
const cors=require('cors')
// userd for generating and verfying 
// token for authentication and authorization purposes 
const jwt=require('jsonwebtoken')
// this is line imports a configuration file 
// from the same directory , which icontains application-wide
// settings and constants.
const config=require('./config')
// this line imports a utility file (utils.js)
// from the same directory, which likely contains
// reusable function and helper for your application. 
const utils=require('./utils')

// this line creates a new instance of the express.js application, 
// which is the main entry point for your server. 
const app = express()
// this line enables cors middleware for your application 
app.use(cors())
//this line enables json parsing for incoming requests.
// this middleware parses incoming requests with json payloads 
// and makes the data available in the req.body object.

// by using app.use(express.json()), youre telling express.js
//to parse json data sent in the request body.
// this is useful when working with apis that send data in json format.
app.use(express.json())



//middleware to verify the token
app.use((request,response,next)=>{
    //check if token is required for the api
    if(
        request.url==='/user/login'||
        request.url==='/user/register'//||
        //request.url.startswith('/image')

    ){
        // skip verifying token 
        next()
        
    }else {
        //get the token
        // console.log("login successful");
        // const token=request.headers['token']
        
        const auth_token=request.headers.authorization;

        const token=auth_token.split(' ')[1];
        console.log("$ ",token);


        if (!token||token.length===0)
        {
            response.send(utils.createErrorResult('missing token'))

        }
        else {
            try {
                //verify token
       

                const payload=jwt.verify(token,config.secret)
        

                //add the userId to the request
                request.userId=payload['id']

                next();
            }
            catch(ex)
            {
                    response.send(utils.createErrorResult('invalid token'))
            }     
                
        }
    }
})

// add the routes
// declaring routes
const userRouter = require('./routes/user')
const categoryRouter = require('./routes/category')
const imageRouter = require('./routes/image')
const propertyRouter = require('./routes/property')
const bookingRouter = require('./routes/booking')




// mouting/linking the route handlers to your express.js 
app.use('/user',userRouter)
app.use('/category',categoryRouter)
app.use('/image',imageRouter)
app.use('/property',propertyRouter)
app.use('/booking',bookingRouter)



app.listen(4000,'0.0.0.0',()=>{
    console.log("server started on port 4000")
})
